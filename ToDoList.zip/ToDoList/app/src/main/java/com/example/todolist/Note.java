package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Note extends AppCompatActivity {

    Button saveB;
    NotesDB notesDB;
    EditText contentT;
    EditText titleT;
    NoteClass note;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        notesDB = new NotesDB(this);
        saveB = findViewById(R.id.saveBtn);
        contentT = findViewById(R.id.contentTxt);
        titleT = findViewById(R.id.titleText);
    }

    public void saveNote(View view) {
        String title = titleT.getText().toString();
        String content = contentT.getText().toString();
        note = new NoteClass(title,content);
        notesDB.addNote(note);
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
