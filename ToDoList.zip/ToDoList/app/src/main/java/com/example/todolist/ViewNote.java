package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ViewNote extends AppCompatActivity {

    EditText Title;
    EditText Content;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_note);
        intent = getIntent();
        Title = findViewById(R.id.title);
        Content = findViewById(R.id.content);
        String old_title = intent.getStringExtra("title");
        NoteClass note = new NoteClass();
        NotesDB notesDB = new NotesDB(this);
        note = notesDB.getNote(old_title);
        Title.setText(note.getTitle());
        Content.setText(note.getContent());
    }

    public void goBack(View view) {


        setResult(RESULT_OK,intent);
        finish();

    }
}
