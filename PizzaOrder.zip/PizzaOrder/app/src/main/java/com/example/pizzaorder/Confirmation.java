/*
Author : Savan Patel
Date: Sept. 27, 2019
Purpose: Assignment 1 - Basic Android
 */
package com.example.pizzaorder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Confirmation extends AppCompatActivity {

    EditText text;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);
        text = findViewById(R.id.txtText);
        intent = getIntent();
        Bundle data = intent.getExtras(); //get the intent data from first activity

        //if the data is not null then read the data and edit the EditText to display the data
        if (data != null) {
            String pizzaSize = (String) data.get("Pizza Size");
            String topping = (String) data.get("Topping");
            String extra = (String) data.get("Extras");
            String contact = (String) data.get("Contact Info");
            String instructions = (String) data.get("Instructions");
            double price = data.getDouble("Total Price");
            text.setText("Contact Info:\nName: "+contact+"\n\nPizza Size: "+pizzaSize+"\nTopping: "+topping+"\nExtras: "+extra+"\n\nSpecial Instructions: "+instructions+"\n\nTotal Price:$"+price);
        }
    }

    //when back button is clicked start a new intent and go back to the main activity
    public void onBackClick(View view) {
        Intent intent1 = new Intent(Confirmation.this,MainActivity.class);
        startActivity(intent1);

    }
}
