/*
Author : Savan Patel
Date: Sept. 27, 2019
Purpose: Assignment 1 - Basic Android
 */
package com.example.pizzaorder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //declaring variables
    EditText specialInstructions, name, address, phoneNumber, emailAddress;
    CheckBox cheese, delivery;
    double pizzaTotal = 0;
    double toppingTotal = 0;
    TextView price;
    double totalPrice = 0;
    Spinner spinner;
    double cheesePrice;
    double deliveryPrice;
    String topping, pizzaSize, extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //this will hide the soft keyboard because on startup activity the focus is on the EditText which brings
        //up the keyboard and we dont want that
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        //initialize variables
        spinner = findViewById(R.id.toppingSpinner);
        fillSpinner(spinner);

        specialInstructions = findViewById(R.id.txtInstructions);
        name = findViewById(R.id.txtName);
        address = findViewById(R.id.txtAddress);
        phoneNumber = findViewById(R.id.txtPhoneNum);
        emailAddress = findViewById(R.id.txtEmailAdd);
        cheese = findViewById(R.id.checkBoxCheese);
        delivery = findViewById(R.id.checkBoxDelivery);
        price = findViewById(R.id.txtPrice);

        //when an item from the spinner is selected update the price
        //using getItemText() to get the item selected text and then looking for a price in it
        //set the price according to the price found in the text and update the total price
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                topping = parent.getSelectedItem().toString();
                if (topping.contains("5")) {
                    toppingTotal = 5;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                else if (topping.contains("7")) {
                    toppingTotal = 7;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                else if (topping.contains("8")) {
                    toppingTotal = 8;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                else if (topping.contains("9")) {
                    toppingTotal = 9;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                else if (topping.contains("10")) {
                    toppingTotal = 10;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                else {
                    toppingTotal = 0;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    //fills in the spinner with the array
    private void fillSpinner(Spinner spinner) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.toppings,R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    //radio button listener to check for when it is clicked
    //updated the total price accordingly
    public void onRadioBtnClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                if (checked) {
                    pizzaSize = ((RadioButton) view).getText().toString();
                    pizzaTotal = 5.50;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                break;
            case R.id.radio2:
                if (checked) {
                    pizzaSize = ((RadioButton) view).getText().toString();
                    pizzaTotal= 7.99;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                break;
            case R.id.radio3:
                if (checked) {
                    pizzaSize = ((RadioButton) view).getText().toString();
                    pizzaTotal= 9.50;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                break;
            case R.id.radio4:
                if (checked) {
                    pizzaSize = ((RadioButton) view).getText().toString();
                    pizzaTotal= 11.38;
                    totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
                    price.setText(String.format("%.2f",totalPrice));
                }
                break;
        }
    }

    //checking if the checkbox are checked or not and calculate total price appropriatley
    public void onCheeseChecked(View view) {
        if (cheese.isChecked()) {
            cheesePrice = 5;
            totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
            price.setText(String.format("%.2f",totalPrice));
            Toast.makeText(MainActivity.this, "Extra Cheese", Toast.LENGTH_SHORT).show();
        }
        else {
            cheesePrice = 0;
            totalPrice = pizzaTotal+toppingTotal+cheesePrice+deliveryPrice;
            price.setText(String.format("%.2f",totalPrice));
            Toast.makeText(MainActivity.this, "Extra Cheese Removed", Toast.LENGTH_SHORT).show();
        }
    }

    public void onDeliveryChecked(View view) {
        if (delivery.isChecked()) {
            deliveryPrice = 5.0;
            totalPrice = pizzaTotal+toppingTotal+deliveryPrice+cheesePrice;
            price.setText(String.format("%.2f",totalPrice));
            Toast.makeText(MainActivity.this, "Include Delivery", Toast.LENGTH_SHORT).show();
        }
        else {
            deliveryPrice = 0;
            totalPrice = pizzaTotal+toppingTotal+deliveryPrice+cheesePrice;
            price.setText(String.format("%.2f",totalPrice));
            Toast.makeText(MainActivity.this, "Delivery Removed", Toast.LENGTH_SHORT).show();
        }
    }

    //when the submit button is presed validate that a pizza size is chosen and contact info is filled
    //create a new itent and send the information over to the next activity
    public void onSubmit(View view) {

        if (!(pizzaTotal == 0) && !name.getText().toString().isEmpty() && !address.getText().toString().isEmpty() && !phoneNumber.getText().toString().isEmpty()) {
            //create the intent
            Intent intent = new Intent(MainActivity.this,Confirmation.class);
            intent.putExtra("Pizza Size",pizzaSize);
            intent.putExtra("Topping",topping);
            if (cheese.isChecked() && delivery.isChecked()) {
                extras = cheese.getText().toString().concat(",").concat(delivery.getText().toString());
            }
            else if (cheese.isChecked() && !delivery.isChecked()) {
                extras = cheese.getText().toString();
            }
            else if (!cheese.isChecked() && delivery.isChecked()) {
                extras = delivery.getText().toString();
            }
            else {
                extras = "None";
            }
            intent.putExtra("Instructions",specialInstructions.getText().toString());
            intent.putExtra("Extras",extras);
            intent.putExtra("Contact Info",name.getText().toString()+"\nAddress:"+address.getText().toString()+"\nPhone Number:"+phoneNumber.getText().toString()+"\nEmail:"+emailAddress.getText().toString());
            intent.putExtra("Total Price",totalPrice);
            startActivity(intent);
        }
        else {
            if (pizzaTotal == 0) {
                Toast.makeText(this, "You must select a pizza size", Toast.LENGTH_SHORT).show();
            }
            else if (name.getText().toString().isEmpty() && address.getText().toString().isEmpty() && phoneNumber.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please fill in all Contact Info fields", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
