package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView number1;
    TextView number2;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1 = findViewById(R.id.input1);
        number2 = findViewById(R.id.input2);
        result = findViewById(R.id.resultLabel);
    }


    public void addNumbers(View view) {
        if(!number1.getText().toString().isEmpty() && !number2.getText().toString().isEmpty()){
            float num1 = Float.parseFloat(number1.getText().toString());
            float num2 = Float.parseFloat(number2.getText().toString());

            result.setText(Float.toString(num1 + num2));
        }

    }

    public void subNumbers(View view) {
        if(!number1.getText().toString().isEmpty() && !number2.getText().toString().isEmpty()) {
            float num1 = Float.parseFloat(number1.getText().toString());
            float num2 = Float.parseFloat(number2.getText().toString());

            result.setText(Float.toString(num1 - num2));
        }
    }

    public void multiplyNumbers(View view) {
        if(!number1.getText().toString().isEmpty() && !number2.getText().toString().isEmpty()) {
            float num1 = Float.parseFloat(number1.getText().toString());
            float num2 = Float.parseFloat(number2.getText().toString());

            result.setText(Float.toString(num1 * num2));
        }
    }

    public void divideNumbers(View view) {
        if(!number1.getText().toString().isEmpty() && !number2.getText().toString().isEmpty()) {
            float num1 = Float.parseFloat(number1.getText().toString());
            float num2 = Float.parseFloat(number2.getText().toString());

            result.setText(Float.toString(num1 / num2));
        }
    }
}
