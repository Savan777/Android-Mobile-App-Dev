package com.example.simpleemailapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText txtSubject,txtTo,txtText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtSubject = findViewById(R.id.txtText);
        txtTo = findViewById(R.id.txtTo);
        txtText = findViewById(R.id.txtText);
    }

    public void sendEmail(View view) {
        String to = txtTo.getText().toString();
        String[] toEmail = to.split(",");
        String subject = txtSubject.getText().toString();
        String text = txtText.getText().toString();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("plain/text");
        intent.putExtra(Intent.EXTRA_EMAIL, toEmail);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(intent,"How do you want to send this message?"));
    }
}
